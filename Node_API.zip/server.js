var ip = require("ip");
const express = require('express')
const app = express()
app.use(express.static(__dirname + '/public'))

app.get('/image', function (req, res) {
  res.json({
    imageURL: "http://" + ip.address() + ":3001/sample.png",
    ipAddress: ip.address()
  })
})

app.listen(3001, ip.address(), function () {
  console.log('Programmable Video Chat token server listening on port http://' + ip.address() + ':3001')
})
